const Pool = require("pg").Pool;

const pool = new Pool({
  user: "postgres",
  host: "Localhost",
  database: "students",
  password: "root",
  port: 5432,
  timeZone: "Asia/Calcutta",
});

module.exports = pool;
