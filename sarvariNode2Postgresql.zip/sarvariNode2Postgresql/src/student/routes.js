const { Router } = require("express");
const Controller = require("./controller");
const router = Router();

router.get("/", Controller.getStudents);
router.post("/", Controller.addStudent);
router.get("/:id", Controller.getStudentsById);
router.delete("/:id", Controller.removeStudentsById);
router.put("/:id", Controller.updateStudentById);

module.exports = router;
