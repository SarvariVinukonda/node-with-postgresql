const pool = require("../../db");
const queries = require("./queries");
const moment = require("moment");

const addStudent = (req, res) => {
  const body = req.body;
  console.log("🚀 ~ file: controller.js ~ line 20 ~ addStudent ~ body", body);

  console.log("getting students post");
  const { name, email, age, dob } = body;
  console.log(email);
  pool.query(queries.checkEmail, [email], (error, result) => {
    if (result.rows.length) {
      console.log("email exists");
      res.send("email exists");
    }
    pool.query(queries.addStudent, [name, email, age, dob], (error, result) => {
      if (error) console.log(error);

      res.status(201).send("success");
      // console.log("🚀 ~ file: controller.js ~ line 34 ~ pool.query ~ res", res)
    });
  });
};

const getStudents = (req, res) => {
  const array = [];
  console.log("getting students");
  pool.query(queries.getStudents, (error, result) => {
    if (error) throw error;
    else if (res.status(200)) {
      result.rows.forEach((ele) => {
        array.push({
          id: ele.id,
          name: ele.name,
          email: ele.email,
          age: ele.age,
          dob: moment(ele.dob).format("DD/MM/YYYY"),
        });
        // const dataArray = ele.dob.split(/[ ,]/);
        // console.log("🚀 ~ file: controller.js ~ line 41 ~ dataArray", dataArray)
      });
      console.log("🚀 ~ file: controller.js ~ line 39 ~ this.array", array);
      res.send(array);
    }
  });
};

const getStudentsById = (req, res) => {
  console.log("getting students");
  const id = parseInt(req.params.id);
  pool.query(
    queries.getStudentsById,
    [parseInt(req.params.id)],
    (error, result) => {
      if (error) console.log(error);
      res.status(200).json(result.rows);
    }
  );
};

const updateStudentById = (req, res) => {
  const id = parseInt(req.params.id);
  console.log(
    "🚀 ~ file: controller.js ~ line 46 ~ updateStudentById ~ id",
    id
  );
  const body = req.body;
  console.log(
    "🚀 ~ file: controller.js ~ line 48 ~ updateStudentById ~ body",
    body
  );
  const { name, email, age, dob } = body;
  console.log(
    "🚀 ~ file: controller.js ~ line 50 ~ updateStudentById ~ name, email, age, dob",
    name,
    email,
    age,
    dob
  );
  const dataArray = dob.split(/[ ,]/);
  console.log(
    "🚀 ~ file: controller.js ~ line 52 ~ updateStudentById ~ dataArray",
    dataArray
  );

  pool.query(queries.getStudentsById, [id], (error, result) => {
    if (error) console.log(error);
    const noStudentFound = !result.rows.length;
    if (noStudentFound) res.send("No student found");

    pool.query(
      queries.updateStudentById,
      [name, email, age, dataArray, id],
      (error, result) => {
        if (error) console.log(error);
        res.status(200).send("Successfully updated");
      }
    );
  });
};

const removeStudentsById = (req, res) => {
  console.log("getting students");
  const id = parseInt(req.params.id);
  pool.query(queries.getStudentsById, [id], (error, result) => {
    if (error) console.log(error);
    const noStudentFound = !result.rows.length;
    if (noStudentFound) res.send("No student found");

    pool.query(queries.removeStudentsById, [id], (error, result) => {
      if (error) console.log(error);
      res.status(200).send("Successfully deleted");
    });
  });
};

module.exports = {
  getStudents,
  getStudentsById,
  addStudent,
  removeStudentsById,
  updateStudentById,
};
