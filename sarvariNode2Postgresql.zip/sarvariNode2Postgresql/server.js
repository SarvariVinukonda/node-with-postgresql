const express = require("express");

const studentRoutes = require("./src/student/routes");
const app = express();
const port = 5700;

app.use(express.json());
app.get("/sandy", (req, res) => {
  res.send("Hello there");
});

app.use("/api/v1", studentRoutes);
app.listen(port, () => console.log("app is running on ", port));
